<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>CMNG</title>
        <? include_once('incs/head.php'); ?>
    </head>

  <body>
    <? include_once("incs/menu.php"); ?>
    <? include_once("incs/slider.php"); ?>
    <? include_once("incs/content-blog.php"); ?>
    <? include_once("incs/footer.php"); ?>
  </body>
</html>